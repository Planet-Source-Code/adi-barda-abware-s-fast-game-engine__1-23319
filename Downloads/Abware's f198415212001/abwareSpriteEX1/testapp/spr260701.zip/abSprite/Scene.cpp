// Scene.cpp : Implementation of CScene
#include "stdafx.h"
#include "AbSpriteEX1.h"
#include "Scene.h"

#define INITGUID
#define PLAY_BACK 2
#define PLAY_FORWARD 1

#include <ddraw.h>
#include <fstream.h>

/////////////////////////////////////////////////////////////////////////////
// CScene

//collections: linked lists

//abActions
struct abAction {
    char* Name;//action name
    int FromFrame;//from wich frame to start animation
    int ToFrame;//wich frame is the last in animation 
    int AutoReverse;//should the dll make reverse animation automaticaly
    int EndFrame;//when the animation ends - wich frame will be drawn
    struct abAction* nxt;//linked list next struct
    struct abAction* prv;//linked list prev struct

};

abAction* ActionAnkor=NULL;
abAction* LastAction=NULL;

//images including backgrounds
struct abImage {
	char* Name;//image name
    char* ImagePath;//image path in order to restore surface when needed
	int Index;//image number
    int Width;
    int Height;
	LPDIRECTDRAWSURFACE7 ImageSurface1;//direct draw surface
	struct abImage *nxt;//next image object in collection
	struct abImage *prv;//prevoiuse object in collection
};
abImage *ImageAnkor=NULL;//ankor to the first abImage
abImage *LastImage=NULL;//pointer to the last image in collection

abImage *BkgrndAnkor=NULL;//ankor to the first background image
abImage *LastBkgrnd=NULL;//pointer to the last background image

//sprites
struct abSprite {
	int x;//x - position
	int y;//y - position
	int CurrentFrame;//current frame in animation
    int HorizonalFrames,VerticalFrames;//number of frames in the image
    int FrameWidth,FrameHeight;//frames dimensions
	char* Name;//sprite name
	int Index;//sprite number
    BOOL Visible;//sprite visible
    bool InAction;//is the sprite in animation process?
    BOOL AutoDelete;//will this sprite automatically deleted after the end of the current anim
    int Continues;//should the animation repeat itself?
    abAction* ActionName;//current action animation
    int ActionDir;//the direction of the animation
    int ActionSpeed;//animation speed 0=fastest
    int ActionSpeedCounter;//speed counter
    BOOL AutoSwitch;//automaticaly switch to another action when this action finished
    char* SwitchAction;//wich action to swich when current action finished
    char* SwitchImage;
    int SwitchHorizonalFrames;
    int SwitchVerticalFrames;
	abImage *surface;//sprite image
	RECT SpriteRect;//position on screen
	struct abSprite *nxt;//next sprite object in collection
	struct abSprite *prv;//prevoiuse object in collection
};
abSprite *SpritesAnkor=NULL;//ankor to the first abSprite
abSprite *LastSprite=NULL;//pointer to the last sprite in collection

//layers
struct abLayer {
    abImage* LayerImage;
    int xFrames;
    int yFrames;
    BOOL active;//does this layer active
    int FrameWidth,FrameHeight;
    int x,y;//current layer position
};

//Fonts
struct abFont {
    char* Name;//font name
    abImage* FontImage;//font image
    int FontWidth;
    int FontHeight;
    struct abFont *nxt;//next item
    struct abFont *prv;//previous item
};
abFont *FontsAnkor=NULL;//ankor to the first font
abFont *LastFont=NULL;//pointer to the last font in collection

//Labels
struct abLabel {
    char* Name;//label's name
    int Top;//vertical position
    int Left;//horizontal position
    char* Caption;//some text to display
    BOOL Visible;//visible or not on screen
    abFont* Font;//which font to use
    struct abLabel *nxt;//next item
    struct abLabel *prv;//previous item
};
abLabel *LabelsAnkor=NULL;//ankor to the first label
abLabel *LastLabel=NULL;//pointer to the last label in collection


//Direct draw objects
LPDIRECTDRAW7          lpDirectDrawObject1=NULL; //direct draw object
LPDIRECTDRAWSURFACE7   lpPrimary1=NULL; //primary surface
LPDIRECTDRAWSURFACE7   lpDDSBack=NULL;//back buffer

//counters
int m_BackgroundCounter=0;
int m_ImageCounter=0;
int m_SpriteCounter=0;
int m_ActionCounter=0;
int m_RenderSpeed=0;
int m_RenderSpeedCounter=0;

HWND m_SceneHwnd;//windows hwnd
RECT m_ScreenRect;//screen dimension

RECT m_Layer[3][100][100];//up to 3 scrolling layers data
abLayer Layer[3];

//declare functions:
BOOL init2(HWND hWnd,long Width,long Height,int ColorDepth);
abImage* GetImage(char* ImageName);//find image in collection
abImage* GetBackground(char* BackgroundName);//find background in collection
abSprite* GetSprite(char* SpriteName);//find sprite in collection
abAction* GetAction(char* ActionName);//find action in collection
abFont* GetFont(char* FontName);//find font in collection
abLabel* GetLabel(char* LabelName);//find label in collection
LPDIRECTDRAWSURFACE7 bitmap_surface(LPCSTR ,RECT*,bool );//build surface from bmp file
void LoadMapA(char* FileName,long xRes,long yRes);//loads scene map file
char* StrMid$(char* Source,unsigned int start,int length);

int ReleaseImages();
int ReleaseBackgrounds();
int ReleaseSprites();
int ReleaseFonts();
int ReleaseLabels();
int draw_sprites();
int PrintLabels();
int PrintCaption(abLabel*);
int RestoreDisplay();
int ClearActions();
int DelSprite(char*); 
void DeleteLabelA(abLabel* Label); 
void SetSpriteImageA(abSprite* Sprite, abImage* Image, int HorizonalFrames, int VerticalFrames);
void StartActionA(abSprite* Sprite,abAction* Action,int Continues);
void ClearLayer(int LayerNum);
void ScrollLayerA(long LayerNum,long x,long y);

LPDIRECTDRAWSURFACE7 bitmap_surface(LPCSTR file_name,RECT *dims=NULL,bool Stretch=false)
{
	HDC hdc;
	HBITMAP bit;
	LPDIRECTDRAWSURFACE7 surf;

	// load the interface bitmap

	bit=(HBITMAP) LoadImageA(NULL,file_name,IMAGE_BITMAP,0,0,
								LR_DEFAULTSIZE|LR_LOADFROMFILE);
	if (!bit) 

		// failed to load, return failure to caller

		return NULL;

	// get bitmap dimensions

	BITMAP bitmap;
    GetObject( bit, sizeof(BITMAP), &bitmap );
	int surf_width;
	int surf_height;

    if (Stretch) {
        surf_width=m_ScreenRect.right;
        surf_height=m_ScreenRect.bottom;
    }
    else {
        surf_width=bitmap.bmWidth;
        surf_height=bitmap.bmHeight;
    }

	// create surface

	HRESULT ddrval;
	DDSURFACEDESC2 ddsd;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
	ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT ;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN; 
	//ddsd.ddsCaps.dwCaps = DDSCAPS_VIDEOMEMORY; 
	ddsd.dwWidth = surf_width;
	ddsd.dwHeight = surf_height; 

	// attempt to create surface

	ddrval=lpDirectDrawObject1->CreateSurface(&ddsd,&surf,NULL);

	// created ok?

	if (ddrval!=DD_OK) {

		// no, release the bitmap and return failure to caller

		DeleteObject(bit);
		return NULL;

	} else {

		// yes, get a DC for the surface

		surf->GetDC(&hdc);

		// generate a compatible DC

		HDC bit_dc=CreateCompatibleDC(hdc);

		// blit the interface to the surface

		SelectObject(bit_dc,bit);

        if (Stretch) {
		    StretchBlt(hdc,0,0,surf_width,surf_height,bit_dc,0,0,bitmap.bmWidth,bitmap.bmHeight,SRCCOPY);
        }
        else {
            BitBlt(hdc,0,0,surf_width,surf_height,bit_dc,0,0,SRCCOPY);
        }


		// release the DCs

		surf->ReleaseDC(hdc);
		DeleteDC(bit_dc);

		// save the dimensions if rectangle pointer provided

		if (dims) {
			dims->left=0;
			dims->top=0;
			dims->right=surf_width;
			dims->bottom=surf_height;
		}
	}

    
    // clear bitmap 

	DeleteObject(bit);

	// return pointer to caller

	return surf;
}



/////////////////////start implementation/////////////////////////////////////

STDMETHODIMP CScene::Init(long Width, long Height, long ColorDepth)
{
	// Purpose: Initialize screen resolution
    if (! init2 (m_SceneHwnd ,Width,Height,ColorDepth)) {
		ATLTRACE("init failed");	
	}

    //store screen dimensions in the screen rect
    m_ScreenRect.bottom=Height;
    m_ScreenRect.right=Width;
    m_ScreenRect.left=0;
    m_ScreenRect.top=0;

	return S_OK;
} 

STDMETHODIMP CScene::get_HWND_Scene(long *pVal)
{
	// TODO: Add your implementation code here
    pVal=(long*)m_SceneHwnd;
	return S_OK;
}

STDMETHODIMP CScene::put_HWND_Scene(long newVal)
{
	// TODO: Add your implementation code here
    m_SceneHwnd=(HWND)newVal;
	return S_OK;
}

STDMETHODIMP CScene::AddImage(BSTR ImageName, BSTR ImagePath)
{

	// Purpose: Add background image to the background's collection
    USES_CONVERSION;//well i want to convert to ansi

    RECT tmpRC;
    //create new abImage using that image
	abImage *NewImage;
	NewImage=new abImage();
	NewImage->Name=strdup(W2A(ImageName));
    NewImage->ImagePath=strdup(W2A(ImagePath));
	NewImage->nxt=0;//and of collection
    NewImage->ImageSurface1=bitmap_surface(NewImage->ImagePath,&tmpRC);

    //set transparent color to black
    DDCOLORKEY              ddck;
    ddck.dwColorSpaceLowValue = 0;
    ddck.dwColorSpaceHighValue = 0;
    NewImage->ImageSurface1->SetColorKey(DDCKEY_SRCBLT, &ddck);
   
	m_ImageCounter++;//one more background image in collection
	NewImage->Index=m_ImageCounter;//set image number
    NewImage->Width=tmpRC.right;
    NewImage->Height=tmpRC.bottom;

	//add the new image to the image collection
	if (m_ImageCounter==1) {//check if first image
        ImageAnkor=new abImage();
		ImageAnkor->nxt=NewImage;//point to the first image
		NewImage->prv=0;//no prev images
	}
	else {//case its not the first image
		LastImage->nxt = NewImage;//update nxt pointer
		NewImage->prv=LastImage;//update prev pointer
	}
	
	LastImage=NewImage;//new image is now the last image

	return S_OK;
}

STDMETHODIMP CScene::AddSprite(BSTR SpriteName, BSTR ImageName,int HorizonalFrames,int VerticalFrames)
{
	// Purpose: Add a new sprite to the collection
    //index= image to attach to the sprite

    abSprite* NewSprite=NULL;

    USES_CONVERSION;

    //init new sprite
    if (HorizonalFrames<1) HorizonalFrames=1;
    if (VerticalFrames<1) VerticalFrames=1;

	NewSprite=new abSprite();
	NewSprite->Name = strdup(W2A(SpriteName));
    NewSprite->Visible=1;
    NewSprite->CurrentFrame=0;//in case of potentional animation
    NewSprite->HorizonalFrames=HorizonalFrames;//how many frames in bmp horizonaly
    NewSprite->VerticalFrames=VerticalFrames;//how many frames in bmp verticaly
    NewSprite->x=0;//default x position
    NewSprite->y=0;//default y position
    NewSprite->surface=GetImage(W2A(ImageName));//get the attached image
    NewSprite->FrameWidth=NewSprite->surface->Width /HorizonalFrames;
    NewSprite->FrameHeight=NewSprite->surface->Height /VerticalFrames;
    NewSprite->ActionDir=PLAY_FORWARD;//by default play animation forward
    NewSprite->ActionName=NULL;//no action attached
    NewSprite->AutoSwitch=FALSE;
    NewSprite->SwitchAction=NULL;
    NewSprite->SwitchImage=NULL;
    NewSprite->InAction=false;//by default no animation is active
    NewSprite->AutoDelete=FALSE;
    m_SpriteCounter++;//one more background image in collection
	NewSprite->Index=m_SpriteCounter;//set image number

    if (NewSprite->surface) {//if valid image was found
	    //add the new sprite to the sprites collection
	    if (m_SpriteCounter==1) {//check if first sprite
            SpritesAnkor=new abSprite();
		    SpritesAnkor->nxt=NewSprite;//point to the first sprite
		    NewSprite->prv=SpritesAnkor;//no prev sprites
	    }
	    else {//case its not the first sprite
		    LastSprite->nxt = NewSprite;//update nxt pointer
		    NewSprite->prv=LastSprite;//update prev pointer
	    }
	    NewSprite->nxt=NULL;//last sprite in the collection
	    LastSprite=NewSprite;//new image is now the last image

    }
    else//no image found - function abort
    {
        free(NewSprite->Name);
        free(NewSprite);
    }

	return S_OK;
}

STDMETHODIMP CScene::AddBackground(BSTR Name, BSTR ImagePath)
{
	// Purpose: Add background image to the background's collection
    USES_CONVERSION;//well i want to convert to ansi
    RECT rc;

    //create new abImage using that image
	abImage *NewImage;
	NewImage=new abImage();
	NewImage->Name=strdup(W2A(Name));
    NewImage->ImagePath=strdup(W2A(ImagePath));
	NewImage->nxt=0;//and of collection
    NewImage->ImageSurface1=bitmap_surface(NewImage->ImagePath,&rc,true);


	m_BackgroundCounter++;//one more background image in collection
	NewImage->Index=m_BackgroundCounter;//set image number

	//add the new image to the image collection
	if (m_BackgroundCounter==1) {//check if first image
        BkgrndAnkor=new abImage();
		BkgrndAnkor->nxt=NewImage;//point to the first image
		NewImage->prv=0;//no prev images
	}
	else {//case its not the first image
		LastBkgrnd->nxt = NewImage;//update nxt pointer
		NewImage->prv=LastBkgrnd;//update prev pointer
	}
	
	LastBkgrnd=NewImage;//new image is now the last image
	
	return S_OK;
}

abImage* GetImage(char* ImageName){

	//gets image name and return a pointer to that image
	abImage* tmpImage;
	BOOL Search=FALSE;

    tmpImage=ImageAnkor->nxt;//find the first image
    if ((tmpImage) && (ImageName)) {
        Search=TRUE;
    }

	//main scan loop while names dont match and not and of collection
    while (Search) {
	    Search=((strcmp(tmpImage->Name,ImageName)!=0));
        if (Search) {
		    tmpImage=tmpImage->nxt;//next element
            Search=(tmpImage)?TRUE:FALSE; 
        }
	}
	return tmpImage;//return the image pointer
	
}

abSprite* GetSprite(char* SpriteName){

	//Gets sprite name and return a pointer to that sprite
    
	abSprite* tmpSprite;
	BOOL Search=FALSE;

    tmpSprite=SpritesAnkor->nxt;//find the first sprite
    if ((tmpSprite) && (SpriteName)) {
        Search=TRUE;
    }

	//main scan loop while names dont match and not and of collection
    while (Search) {
	    Search=((strcmp(tmpSprite->Name,SpriteName)!=0));
        if (Search) {
		    tmpSprite=tmpSprite->nxt;//next element
            Search=(tmpSprite)?TRUE:FALSE; 
        }
	}
	return tmpSprite;//return the sprite pointer
	
}

abAction* GetAction(char* ActionName) {

	//Gets action name and return a pointer to that action
	abAction* tmpAction;
	BOOL Search=FALSE;

    tmpAction=ActionAnkor->nxt;//find the first action
    if ((tmpAction) && (ActionName)) {
        Search=TRUE;
    }

	//main scan loop while names dont match and not and of collection
    while (Search) {
	    Search=((strcmp(tmpAction->Name,ActionName)!=0));
        if (Search) {
		    tmpAction=tmpAction->nxt;//next element
            Search=(tmpAction)?TRUE:FALSE; 
        }
	}
	return tmpAction;//return the action pointer

}

abFont* GetFont(char* FontName) {
    
    //Gets the specified font from the fonts collection
	abFont* tmpFont;
	BOOL Search=FALSE;

    tmpFont=FontsAnkor->nxt;//find the first font
    if ((tmpFont) && (FontName)) {
        Search=TRUE;
    }

	//main scan loop while names dont match and not and of collection
    while (Search) {
	    Search=((strcmp(tmpFont->Name,FontName)!=0));
        if (Search) {
		    tmpFont=tmpFont->nxt;//next element
            Search=(tmpFont)?TRUE:FALSE; 
        }
	}

    if (!tmpFont) tmpFont=FontsAnkor->nxt;//if no font was found use the first one
	return tmpFont;//return the font pointer

}

abLabel* GetLabel(char* LabelName) {

    //Gets the specified label from the labels collection
	abLabel* tmpLabel;
	BOOL Search=FALSE;

    tmpLabel=LabelsAnkor->nxt;//find the first font
    if ((tmpLabel) && (LabelName)) {
        Search=TRUE;
    }

	//main scan loop while names dont match and not and of collection
    while (Search) {
	    Search=((strcmp(tmpLabel->Name,LabelName)!=0));
        if (Search) {
		    tmpLabel=tmpLabel->nxt;//next element
            Search=(tmpLabel)?TRUE:FALSE; 
        }
	}
	return tmpLabel;//return the label pointer

}


BOOL init2(HWND hWnd,long Width,long Height,int ColorDepth){

    
    //clear layers
    ClearLayer(0);
    ClearLayer(1);
    ClearLayer(2);

    // Create the main DirectDraw object
    int ddrval;
	ddrval = DirectDrawCreateEx(NULL, (LPVOID*)&lpDirectDrawObject1, IID_IDirectDraw7, NULL);
	if (ddrval != DD_OK) {
		//ErrStr=Err_DirectDrawCreate;
		return FALSE;
	}


    // Set our cooperative level

    ddrval = lpDirectDrawObject1->SetCooperativeLevel(hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
    if (ddrval != DD_OK) {
		return FALSE;
	}

	// Set the display mode

	ddrval = lpDirectDrawObject1->SetDisplayMode( Width, Height, ColorDepth, 0, 0);
	if (ddrval !=DD_OK) {
		//ErrStr=Err_DispMode;
		return FALSE;
	}

    // Create the primary surface with 1 back buffer

    DDSURFACEDESC2 ddsd;
	DDSCAPS2 ddscaps;
	ZeroMemory(&ddsd,sizeof(ddsd));
    ddsd.dwSize = sizeof( ddsd );
    ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
                          DDSCAPS_FLIP | 
                          DDSCAPS_COMPLEX | DDSCAPS_VIDEOMEMORY;
    ddsd.dwBackBufferCount = 1;
    ddrval = lpDirectDrawObject1->CreateSurface( &ddsd, &lpPrimary1, NULL );
	if (ddrval!=DD_OK) {
		//ErrStr=Err_CreateSurf;
		return FALSE;
	}

  // Fetch back buffer interface
  ddscaps.dwCaps=DDSCAPS_BACKBUFFER | DDSCAPS_VIDEOMEMORY;
  ddscaps.dwCaps2 = 0;
  ddscaps.dwCaps3 = 0;
  ddscaps.dwCaps4 = 0;
  ddrval=lpPrimary1->GetAttachedSurface(&ddscaps,&lpDDSBack);
	if (ddrval!=DD_OK) {
		//ErrStr=Err_CreateSurf;
		return FALSE;
	}

    return TRUE;
}


int RestoreDisplay() {

    //restore display mode - return control to windows
    if (lpDirectDrawObject1 !=NULL){
        if (lpDDSBack !=NULL) lpDDSBack->Release();
        if (lpPrimary1 !=NULL) lpPrimary1->Release();
    } 

    //release collections memory:
    ReleaseImages();//free images
    ReleaseBackgrounds();//free backgrounds
    ReleaseSprites();//free sprites memory
    ClearActions();//free actions memory
    ReleaseFonts();
    ReleaseLabels();
    lpDirectDrawObject1->RestoreDisplayMode();
    
    //PostQuitMessage(0);
    
    return 1;
}

int ReleaseFonts() {
    //Release fonts memory
	abFont* tmpFont;
    abFont* DelFont;

    if (FontsAnkor){//case there is something in the collection
	    tmpFont=FontsAnkor->nxt;//find the first font

	    //main scan loop while names dont match and not and of collection
	    while (tmpFont!=NULL){
            DelFont=tmpFont;//remember current location
            free(DelFont->Name);
            tmpFont=tmpFont->nxt ;//next element
            free(DelFont);//free memory
	    }
        free(FontsAnkor);//free collection ankor
    }//fonts ankor
	return 1;   

}

int ReleaseLabels() {
    //Release labels memory
	abLabel* tmpLabel;
    abLabel* DelLabel;

    if (LabelsAnkor){//case there is something in the collection
	    tmpLabel=LabelsAnkor->nxt;//find the first label

	    //main scan loop while names dont match and not and of collection
	    while (tmpLabel!=NULL){
            DelLabel=tmpLabel;//remember current location
            free(DelLabel->Name);
            free(DelLabel->Caption);
            tmpLabel=tmpLabel->nxt ;//next element
            free(DelLabel);//free memory
	    }
        free(LabelsAnkor);//free collection ankor
    }//fonts ankor
	return 1;   

}


int ClearActions() {
    //release actions collection
	abAction* tmpAction;
    abAction* DelAction;

    if (ActionAnkor){//case there is something in the collection
	    tmpAction=ActionAnkor->nxt ;//find the first action

	    //main scan loop while names dont match and not end of collection
	    while (tmpAction){
            DelAction=tmpAction;//remember current location
            free(DelAction->Name);
            tmpAction=tmpAction->nxt ;//next element
            free(DelAction);//free memory
		    
	    }
        free(ActionAnkor);//free collection ankor
    }//action ankor
	return 1;   

}

int ReleaseSprites(){
    
    //release sprites collections
	abSprite* tmpSprite;
    abSprite* DelSprite;

    if (SpritesAnkor){//case there is something in the collection
	    tmpSprite=SpritesAnkor->nxt ;//find the first image

	    //main scan loop while names dont match and not and of collection
	    while (tmpSprite!=NULL){
            DelSprite=tmpSprite;//remember current location
            free(DelSprite->Name);
            free(DelSprite->SwitchAction);
            free(DelSprite->SwitchImage);

            tmpSprite=tmpSprite->nxt ;//next element
            free(DelSprite);//free memory
		    
	    }
        free(SpritesAnkor);//free collection ankor
    }//image ankor
	return 1;   

}


int ReleaseImages() {

    //release images collections
	abImage* tmpImage;
    abImage* DelImage;

    if (ImageAnkor){//case there is something in the collection
	    tmpImage=ImageAnkor->nxt ;//find the first image

	    //main scan loop while names dont match and not and of collection
	    while (tmpImage!=NULL){
            DelImage=tmpImage;//remember current location
            DelImage->ImageSurface1->Release();//free surface
            free(DelImage->ImagePath);
            free(DelImage->Name);
            tmpImage=tmpImage->nxt;//next element
            free(DelImage);//free memory
		    
	    }
        free(ImageAnkor);//free collection ankor
    }//image ankor
	return 1;   
}

int ReleaseBackgrounds() {

    //release images collections
	abImage* tmpImage;
    abImage* DelImage;

    if (BkgrndAnkor){//case there is something in the collection
	    tmpImage=BkgrndAnkor->nxt ;//find the first image

	    //main scan loop while names dont match and not and of collection
	    while (tmpImage!=NULL){
            DelImage=tmpImage;//remember current location
            DelImage->ImageSurface1->Release();//free surface
            free(DelImage->ImagePath);
            free(DelImage->Name);
            tmpImage=tmpImage->nxt;//next element
            free(DelImage);//free memory
		    
	    }
        free(BkgrndAnkor);//free collection ankor
    }
	return 1;   
}

STDMETHODIMP CScene::Restore()
{
	
    RestoreDisplay();
	return S_OK;
}

STDMETHODIMP CScene::Render(VARIANT Background)
{
	// TODO: Add your implementation code here

    char* Name=NULL;//background's name
    int Index=NULL;//background's index
    int i;
    BOOL bNoBackground=FALSE;

    abImage* tmpImage=NULL;

    USES_CONVERSION;

    m_RenderSpeedCounter--;
    if (m_RenderSpeedCounter<0) {
        m_RenderSpeedCounter=m_RenderSpeed;
        
        //check what type is this variant:
        switch (Background.vt){
            case VT_BSTR://string
                //W2A(Background.bstrVal);//convert to ansi
                Name=W2A(Background.bstrVal);
                break;
            case VT_I4://long - int 32 bit
                Index=(int)Background.lVal;
                break;
            case VT_I2://integer 16 bit
                Index=(int)Background.iVal;
                break;
            case VT_INT://int
                Index=(int)Background.intVal;
                break;

        }//switch

        if (Name){//find background by name
            tmpImage=GetBackground(Name);//get selected background
            if (tmpImage) {//if background image was found
                lpDDSBack->BltFast(0,0,tmpImage->ImageSurface1 ,NULL,DDBLTFAST_WAIT);
            } else { bNoBackground=TRUE; }// no background image was found
        } else { bNoBackground=TRUE; }//no background image name was supplied 
        

        if (bNoBackground) {//clear backbuffer by blitting            
            DDBLTFX ddbltfx;
            ddbltfx.dwSize = sizeof(ddbltfx);
            ddbltfx.dwFillColor = 0;
            HRESULT rval = lpDDSBack->Blt(NULL,NULL,NULL,DDBLT_WAIT|DDBLT_COLORFILL,&ddbltfx);
        }

	        
        for (i=0;i<3;i++) {
            //scroll layer if its active
            if (Layer[i].active) {
                ScrollLayerA(i,Layer[i].x,Layer[i].y);
            }
        }
        //draw sprites
        draw_sprites();
        PrintLabels();
	    // flip to the primary surface
        if (lpPrimary1->Flip(0,DDFLIP_WAIT)==DDERR_SURFACELOST) {
			//case faild to flip
			ATLTRACE("render flip failed");
		}
    
    }//render

 	return S_OK;
}

abImage* GetBackground(char* BackgroundName){

	//gets image name and return a pointer to that image
	abImage* tmpImage;
	BOOL Search=FALSE;

    tmpImage=BkgrndAnkor->nxt;//find the first image
    if ((tmpImage) && (BackgroundName)) {
        Search=TRUE;
    }

	//main scan loop while names dont match and not and of collection
    while (Search) {
	    Search=((strcmp(tmpImage->Name,BackgroundName)!=0));
        if (Search) {
		    tmpImage=tmpImage->nxt;//next element
            Search=(tmpImage)?TRUE:FALSE; 
        }
	}
	return tmpImage;//return the image pointer
	
}

/*
void draw_slide(abImage* surf)
{
	// draw the object to the screen

	lpDDSBack->BltFast(0,0,surf->ImageSurface1 , &m_ScreenRect,DDBLTFAST_WAIT);

}
*/

int draw_sprites() {

    //draw sprites to the backbuffer

    abSprite* tmpSprite;
    abSprite* delSprite;

    abAction* tmpAction;
    int CurrentFrame ;
    BOOL bDelete=FALSE;//auto delete after sprite animation

    if (SpritesAnkor){//case there is something in the collection
	    tmpSprite=SpritesAnkor->nxt;//find the first image

	    //main scan loop while names dont match and not end of collection
	    while (tmpSprite!=NULL){

            //calc sprite's rect - usefull for animations
            RECT rc;
            CurrentFrame=tmpSprite->CurrentFrame;
            //decide wich current frame should be drawn now:
            if (tmpSprite->InAction) {//case sprite in animation action
                tmpSprite->ActionSpeedCounter++;
                if (tmpSprite->ActionSpeedCounter>tmpSprite->ActionSpeed) {
                    tmpSprite->ActionSpeedCounter=0;
                
                    //tmpAction=GetAction(tmpSprite->ActionName);
                    tmpAction=tmpSprite->ActionName;
                    if (tmpSprite->ActionDir==PLAY_FORWARD) {//animate forward
                        CurrentFrame++;//get next frame 
                        if (CurrentFrame>tmpAction->ToFrame) {//end of animation
                            if (tmpAction->AutoReverse==1) {//play auto reverse
                                tmpSprite->ActionDir=PLAY_BACK;
                                CurrentFrame-=2;
                                if (CurrentFrame<tmpAction->FromFrame) CurrentFrame=tmpAction->FromFrame;
                            }//play auto reverse
                            else
                            {
                                CurrentFrame=tmpAction->EndFrame;//end of animation
                                if (tmpSprite->Continues==1) {//repeat animation
                                    CurrentFrame=tmpAction->FromFrame;
                                }
                                else {
                                    tmpSprite->InAction=false;//stop animation    
                                }
                                bDelete=(tmpSprite->AutoDelete);//check for auto delete
                            }
                        }//end of animation
                    }//animate forward
                    else//animate backward
                    {
                        CurrentFrame=tmpSprite->CurrentFrame-1;
                        if (CurrentFrame<tmpAction->FromFrame) {//end of animation
                            CurrentFrame=tmpAction->FromFrame;
                            if (tmpSprite->Continues==1) {//repeat animation
                                tmpSprite->ActionDir=PLAY_FORWARD;
                            }
                            else {
                                tmpSprite->InAction=false;//stop animation
                            }
                            bDelete=(tmpSprite->AutoDelete);//check for auto delete
                        }//end of animation
                    }//animate backward
                }//animation speed
            }//animation process

            tmpSprite->CurrentFrame=CurrentFrame;//set the current frame

            //calculate sprite rect according to the current frame
            int row=tmpSprite->CurrentFrame / tmpSprite->HorizonalFrames; 
            int col=tmpSprite->CurrentFrame % tmpSprite->HorizonalFrames;//mod
            rc.top=row*tmpSprite->FrameHeight;
            rc.left=col*tmpSprite->FrameWidth;
            rc.right=rc.left+tmpSprite->FrameWidth ;
            rc.bottom=rc.top+tmpSprite->FrameHeight ;

            //in case the sprite rect is out of the screen, it should be recalculate
            int deltX= (tmpSprite->FrameWidth+tmpSprite->x );
            if (deltX-m_ScreenRect.right>0 ){//case rect is out of the screen on the right
                rc.right-=(deltX-m_ScreenRect.right);
                tmpSprite->x=m_ScreenRect.right-(rc.right-rc.left);
            }
            else{//case rect is out of the screen on the left
                if (tmpSprite->x<0){
                    rc.left+=(tmpSprite->x*-1);
                    tmpSprite->x=0;
                }
            }//rect is out of the screen


            int deltY= (tmpSprite->FrameHeight+tmpSprite->y );
            if (deltY-m_ScreenRect.bottom>0 ){//case rect is out of the screen on the bottom
                rc.bottom-=(deltY-m_ScreenRect.bottom);
                tmpSprite->y=m_ScreenRect.bottom-(rc.bottom-rc.top);
            }
            else{//case rect is out of the screen on the top
                if (tmpSprite->y<0){
                    rc.top+=(tmpSprite->y*-1);
                    tmpSprite->y=0;
                }
            }//rect is out of the screen


            //draw sprite to backbuffer
            if (tmpSprite->Visible) {//check if sprite is visible
                //lpDDSBack->BltFast(tmpSprite->x ,tmpSprite->y,tmpSprite->surface->ImageSurface1,&rc,DDBLTFAST_SRCCOLORKEY | DDBLTFAST_WAIT);
                lpDDSBack->BltFast(tmpSprite->x ,tmpSprite->y,tmpSprite->surface->ImageSurface1,&rc,DDBLTFAST_SRCCOLORKEY );
            }
            
            delSprite=tmpSprite;
            tmpSprite=tmpSprite->nxt;//next element
		    if (bDelete) {
                if (delSprite->AutoSwitch) {
                    delSprite->AutoDelete=FALSE;
                    delSprite->AutoSwitch=FALSE;
                    SetSpriteImageA(delSprite,GetImage(delSprite->SwitchImage),delSprite->SwitchHorizonalFrames,delSprite->SwitchVerticalFrames);
                    StartActionA(delSprite,GetAction(delSprite->SwitchAction),delSprite->Continues);
                }
                else
                {
                    DelSprite(delSprite->Name);
                }
                bDelete=FALSE;
            }

	    }
    }
    return 1;
}

STDMETHODIMP CScene::MoveSprite(BSTR Sprite, int x, int y, int Frame)
{
	// Purpose: move selected sprite and animate 
    USES_CONVERSION;//work in ansi mode    
    abSprite* tmpSprite=GetSprite(W2A(Sprite));//find the specified sprite

    if (tmpSprite) {
        tmpSprite->x=x;
        tmpSprite->y=y;

        //update sprite's rect ( to use with collisions )
        tmpSprite->SpriteRect.left=x;
        tmpSprite->SpriteRect.top=y;
        tmpSprite->SpriteRect.bottom=y+tmpSprite->FrameHeight;
        tmpSprite->SpriteRect.right=x+tmpSprite->FrameWidth;
        if (!tmpSprite->InAction) {
            tmpSprite->CurrentFrame=Frame;
        }
    }

	return S_OK;
}


/*
long DDColorMatch(IDirectDrawSurface7 * pdds, COLORREF rgb)
{
    COLORREF                rgbT;
    HDC                     hdc;
    DWORD                   dw = CLR_INVALID;
    DDSURFACEDESC2          ddsd;
    HRESULT                 hres;

    //
    //  Use GDI SetPixel to color match for us
    //
    if (rgb != CLR_INVALID && pdds->GetDC(&hdc) == DD_OK)
    {
        rgbT = GetPixel(hdc, 0, 0);     // Save current pixel value
        SetPixel(hdc, 0, 0, rgb);       // Set our value
        pdds->ReleaseDC(hdc);
    }
    //
    // Now lock the surface so we can read back the converted color
    //
    ddsd.dwSize = sizeof(ddsd);
    while ((hres = pdds->Lock(NULL, &ddsd, 0, NULL)) == DDERR_WASSTILLDRAWING)
        ;
    if (hres == DD_OK)
    {
        dw = *(DWORD *) ddsd.lpSurface;                 // Get DWORD
        if (ddsd.ddpfPixelFormat.dwRGBBitCount < 32)
            dw &= (1 << ddsd.ddpfPixelFormat.dwRGBBitCount) - 1;  // Mask it to bpp
        pdds->Unlock(NULL);
    }
    //
    //  Now put the color that was there back.
    //
    if (rgb != CLR_INVALID && pdds->GetDC(&hdc) == DD_OK)
    {
        SetPixel(hdc, 0, 0, rgbT);
        pdds->ReleaseDC(hdc);
    }
    return dw;
}
*/

STDMETHODIMP CScene::AddAction(BSTR Name, int FromFrame, int ToFrame, int AutoReverse, int EndFrame)
{

    // Purpose: Add background action to the action's collection
    USES_CONVERSION;//well i want to convert to ansi

    //create new action using that action
	abAction *NewAction;
	NewAction=new abAction();
	NewAction->Name=strdup(W2A(Name));
    NewAction->FromFrame=FromFrame;
    NewAction->ToFrame=ToFrame;
    NewAction->AutoReverse=AutoReverse;
    NewAction->EndFrame=EndFrame;
	NewAction->nxt =0;//and of collection

	m_ActionCounter++;//one more action in collection

	//add the new action to the action collection
	if (m_ActionCounter==1) {//check if first action
        ActionAnkor=new abAction();
		ActionAnkor->nxt=NewAction;//point to the first action
		NewAction->prv=0;//no prev actions
	}
	else {//case its not the first action
		LastAction->nxt = NewAction;//update nxt pointer
		NewAction->prv=LastAction;//update prev pointer
	}
	
	LastAction=NewAction;//new action is now the last action

	return S_OK;
}

STDMETHODIMP CScene::StartAction(BSTR SpriteName, BSTR ActionName, int Continues)
{
	// Purpose: attach action to the specified sprite
    USES_CONVERSION;

    abSprite* tmpSprite=GetSprite(W2A(SpriteName));
    abAction* tmpAction=GetAction(W2A(ActionName));
    StartActionA(tmpSprite,tmpAction,Continues);

	return S_OK;
}

void StartActionA(abSprite* Sprite,abAction* Action,int Continues)
{

    if ((Sprite) && (Action)) {//check these objects are valid
        
        if (!Sprite->InAction) {//check that there's no other action running
            if (Sprite->ActionName) {//check that we have some action in it
                free(Sprite->ActionName);
            }
            Sprite->ActionName=Action;//->Name;
            Sprite->ActionDir=PLAY_FORWARD;
            Sprite->CurrentFrame=Action->FromFrame;
            Sprite->Continues=Continues;
            Sprite->InAction=true;//from now, the sprite is in action!
        }
    }

}


STDMETHODIMP CScene::StopAction(BSTR SpriteName, int Frame)
{
	// Purpose: stop sprite from its current animation
    USES_CONVERSION;

    abSprite* tmpSprite=GetSprite(W2A(SpriteName));
 
    if (tmpSprite) {
        tmpSprite->ActionDir=PLAY_FORWARD;
        tmpSprite->CurrentFrame=Frame;
        tmpSprite->InAction=false;
    }
	return S_OK;
}


STDMETHODIMP CScene::IsColide(BSTR Sprite1, BSTR Sprite2, VARIANT_BOOL *retval)
{
	// Purpose: check if two sprites colide
    USES_CONVERSION;

    abSprite* abSprite1=GetSprite(W2A(Sprite1));
    abSprite* abSprite2=GetSprite(W2A(Sprite2));
    RECT DestRect;

    if (abSprite1 && abSprite2) {//check for sprite collision
        *retval=(IntersectRect(&DestRect,&abSprite1->SpriteRect,&abSprite2->SpriteRect)
            && (abSprite1->Visible) && (abSprite2->Visible) 
			&& (! abSprite1->AutoDelete) && (! abSprite2->AutoDelete));
    }

	return S_OK;
}

STDMETHODIMP CScene::SetActionSpeed(BSTR SpriteName, int SpeedLevel)
{
	// Purpose: sets the sprite's animation speed
    USES_CONVERSION;
    abSprite* tmpSprite=GetSprite(W2A(SpriteName));

    if (tmpSprite) {
        tmpSprite->ActionSpeed=SpeedLevel;
        tmpSprite->ActionSpeedCounter=0;
    }

	return S_OK;
}

STDMETHODIMP CScene::get_RenderSpeed(long *pVal)
{
	// TODO: Add your implementation code here
    *pVal=m_RenderSpeed;
	return S_OK;
}

STDMETHODIMP CScene::put_RenderSpeed(long newVal)
{
	// TODO: Add your implementation code here
    m_RenderSpeed=newVal;
    m_RenderSpeedCounter=m_RenderSpeed;
	return S_OK;
}


STDMETHODIMP CScene::SetSpriteImage(BSTR SpriteName, BSTR ImageName, int HorizonalFrames, int VerticalFrames)
{

    USES_CONVERSION;

    char* Name=NULL;//background's name
    abSprite* NewSprite=GetSprite(W2A(SpriteName));
    abImage* NewImage=GetImage(W2A(ImageName));
    SetSpriteImageA(NewSprite,NewImage,HorizonalFrames,VerticalFrames);

	return S_OK;
}


void SetSpriteImageA(abSprite* Sprite, abImage* Image, int HorizonalFrames, int VerticalFrames)
{

    char* Name=NULL;//background's name

    if (Sprite && Image) {
        //if (!(NewSprite->surface==NewImage)) {
            //init new sprite
            if (HorizonalFrames<1) HorizonalFrames=1;
            if (VerticalFrames<1) VerticalFrames=1;

            Sprite->CurrentFrame=0;//in case of potentional animation
            Sprite->HorizonalFrames=HorizonalFrames;//how many frames in bmp horizonaly
            Sprite->VerticalFrames=VerticalFrames;//how many frames in bmp verticaly
            Sprite->surface=Image;//get the attached image
            Sprite->FrameWidth=Sprite->surface->Width /HorizonalFrames;
            Sprite->FrameHeight=Sprite->surface->Height /VerticalFrames;
            Sprite->ActionDir=PLAY_FORWARD;//by default play animation forward
            Sprite->ActionName=NULL;//no action attached
            Sprite->InAction=false;//by default no animation is active
        //}// ! new sprite == new image
    }
	
}

STDMETHODIMP CScene::get_SpriteVisible(BSTR SpriteName, VARIANT_BOOL *pVal)
{
	// TODO: Add your implementation code here
    USES_CONVERSION;
    abSprite* tmpSprite=GetSprite(W2A(SpriteName));

    if (tmpSprite) {
        *pVal=tmpSprite->Visible;
    }

	return S_OK;
}

STDMETHODIMP CScene::put_SpriteVisible(BSTR SpriteName, VARIANT_BOOL newVal)
{
	// TODO: Add your implementation code here
    USES_CONVERSION;
    abSprite* tmpSprite=GetSprite(W2A(SpriteName));

    if (tmpSprite) {
        tmpSprite->Visible=newVal;
    }


	return S_OK;
}

STDMETHODIMP CScene::DeleteSprite(BSTR SpriteName)
{
	// TODO: Add your implementation code here
    USES_CONVERSION;
    char* SName=W2A(SpriteName);

    DelSprite(SName);

	return S_OK;
}

int DelSprite(char* SpriteName) 
{

    abSprite* tmpSprite=GetSprite(SpriteName);

    if (tmpSprite) {
        tmpSprite->prv->nxt=tmpSprite->nxt;
        if (tmpSprite->nxt) {
            tmpSprite->nxt->prv=tmpSprite->prv;
        }
        if (tmpSprite==LastSprite) {//case the deleted sprite is the last one
            LastSprite=tmpSprite->prv;
        }
        free(tmpSprite->Name);
        free(tmpSprite->SwitchAction);
        free(tmpSprite->SwitchImage);
        free(tmpSprite);
    }

    return 1;
}

void DeleteLabelA(abLabel* Label) 
{

    if (Label) {
        Label->prv->nxt=Label->nxt;
        if (Label->nxt) {
            Label->nxt->prv=Label->prv;
        } else {
            LastLabel=Label->prv;
        }

        free(Label->Name);
        free(Label->Caption );
        free(Label);
    }


}


STDMETHODIMP CScene::get_AutoDelete(BSTR SpriteName, VARIANT_BOOL *pVal)
{
	// TODO: Add your implementation code here
    USES_CONVERSION;
    abSprite* tmpSprite=GetSprite(W2A(SpriteName));

    if (tmpSprite) {
        *pVal=tmpSprite->AutoDelete;
    }


	return S_OK;
}

STDMETHODIMP CScene::put_AutoDelete(BSTR SpriteName, VARIANT_BOOL newVal)
{
	// TODO: Add your implementation code here
    USES_CONVERSION;
    abSprite* tmpSprite=GetSprite(W2A(SpriteName));

    if (tmpSprite) {
        tmpSprite->AutoDelete=newVal;
    }
	return S_OK;
}


STDMETHODIMP CScene::AutoActionSwitch(BSTR SpriteName, BSTR ActionName, BSTR ImageName,int HorizonalFrames, int VerticalFrames)
{
	// TODO: Add your implementation code here
    USES_CONVERSION;
    abSprite* tmpSprite=GetSprite(W2A(SpriteName));
    if (tmpSprite) {
        tmpSprite->AutoSwitch=TRUE;
        tmpSprite->SwitchAction=strdup(W2A(ActionName));
        tmpSprite->SwitchImage=strdup(W2A(ImageName));
        tmpSprite->SwitchHorizonalFrames=HorizonalFrames;
        tmpSprite->SwitchVerticalFrames=VerticalFrames;
    }

	return S_OK;
}

STDMETHODIMP CScene::LoadMap(BSTR FileName, long xRes, long yRes)
{
	// TODO: Add your implementation code here
    USES_CONVERSION;

    //clear layers
    ClearLayer(0);
    ClearLayer(1);
    ClearLayer(2);

    //set layer resolution
    for (int i=0;i<3;i++) {
        Layer[i].FrameWidth=m_ScreenRect.right/xRes;
        Layer[i].FrameHeight=m_ScreenRect.bottom/yRes;
        Layer[i].xFrames=xRes;
        Layer[i].yFrames=yRes;
    }

    LoadMapA(W2A(FileName),xRes,yRes);

	return S_OK;
}

void LoadMapA(char* FileName,long xRes,long yRes)
{
    const BUFFER_SIZE=25;//23 chars + cr + null terminating sign
    RECT rc;
    int layer,row,col;
    char buffer[BUFFER_SIZE];

    ifstream inpFile(FileName, ios::in);//open map file

    if (inpFile.good() ) {
        while (! inpFile.eof()) {
            inpFile.getline(buffer,BUFFER_SIZE);
            if (buffer) {
                layer=atoi(StrMid$(buffer,1,1));
                col=atoi(StrMid$(buffer,2,3));
                row=atoi(StrMid$(buffer,5,3));
                rc.left=atoi(StrMid$(buffer,8,4));
                rc.top=atoi(StrMid$(buffer,12,4));
                rc.right=atoi(StrMid$(buffer,16,4));
                rc.bottom=atoi(StrMid$(buffer,20,4));
                if (layer>=0 && layer<=2 && col>=0 && col<=99 && row>=0 && row<=99) {
                    m_Layer[layer][col][row]=rc;
                }
                
            }
        }//end of file
    }//file good
    inpFile.close();

}

char* StrMid$(char* Source,unsigned int start,int length)
{
    
    if (start>strlen(Source) || start<1 || length<1) {
        return NULL;
    }

    unsigned int i=strlen(Source)-(start+length);
    if (i<0) {
        length+=i;
    }

    char* dest=new char(length);
    
    for (i=start;i<start+length;i++) {
        dest[i-start]=Source[i-1];
        
    }
    dest[length]=NULL;//end of string
    
    return dest;
}

STDMETHODIMP CScene::SetLayerImage(long LayerNum, BSTR ImageName)
{
	// TODO: Add your implementation code here
    USES_CONVERSION;

    if (LayerNum>=0 && LayerNum<=2) {
        Layer[LayerNum].LayerImage=GetImage(W2A(ImageName));//sets layer image name
    }

	return S_OK;
}

void ScrollLayerA(long LayerNum,long x,long y)
{

    int xcnt=0;//x draw counter
    int ycnt=0;//y draw counter

    int xCol=x/Layer[LayerNum].FrameWidth;//from wich horizonal brick start draing
    int yCol=y/Layer[LayerNum].FrameHeight;//from wich vertical brick start draing
    
    int mx=x%Layer[LayerNum].FrameWidth;//how much to cut horizonaly from the first brick
    int my=y%Layer[LayerNum].FrameHeight;//how much to cut verticaly from the first brick
    int cmx=mx;
    int cmy=my;
    int iRow,iCol;//point to some brick
    int xstp,ystp;//brick size (width,height)
    int edgX,edgY;//how much to cut from the last brick

    RECT rc;//temporary rect for bltfast function

    //Main scanning loop - scan all the relevant bricks to fill one screen size
    for (iRow=yCol;iRow<=yCol+Layer[LayerNum].yFrames ;iRow++) {
        ystp=Layer[LayerNum].FrameHeight;//default vertical step
        for (iCol=xCol;iCol<=xCol+Layer[LayerNum].xFrames ;iCol++) {
            xstp=Layer[LayerNum].FrameWidth;//default horizonal step
            if (m_Layer[LayerNum][iCol][iRow].left>-1) {//check if brick is not empty
                edgX=xstp-(m_ScreenRect.right-xcnt);//how much to cut from last brick
                edgY=ystp-(m_ScreenRect.bottom-ycnt);//how much to cut from last brick
                if (edgX<0) edgX=0;//no cut is needed
                if (edgY<0) edgY=0;//no cut is needed
                //calculate brick's rect
                rc.left=m_Layer[LayerNum][iCol][iRow].left + cmx;
                rc.top=m_Layer[LayerNum][iCol][iRow].top+cmy;
                rc.bottom=m_Layer[LayerNum][iCol][iRow].bottom-edgY;
                rc.right=m_Layer[LayerNum][iCol][iRow].right-edgX;
                //draw brick on the screen
                lpDDSBack->BltFast(xcnt ,ycnt,Layer[LayerNum].LayerImage->ImageSurface1,&rc,DDBLTFAST_SRCCOLORKEY | DDBLTFAST_WAIT);
            }
            if (cmx>0) {//case its the first brick
                xstp-=cmx;//recalc step length
                cmx=0;
            }
            xcnt+=xstp;//increase horizonal step
        }//next Column
        xcnt=0;//zero horizonal counter
        cmx=mx;
        if (cmy>0) {//case its the first brick
            ystp-=cmy;//recalc step length
            cmy=0;
        }
        ycnt+=ystp;//increase vertical step
    }//next Row

}   

void ClearLayer(int LayerNum)
{
    //clear layer data
    int c,r;

    Layer[LayerNum].active=TRUE;//layer active - will be shown on screen
    for (c=0;c<100;c++) {
        for (r=0;r<100;r++) {
            m_Layer[LayerNum][c][r].left=-1;//-1 = not to use this rect
            
        }
    }
        
}

STDMETHODIMP CScene::ScrollLayer(long LayerNum, long x, long y)
{
	// TODO: Add your implementation code here
    Layer[LayerNum].x=x;
    Layer[LayerNum].y=y;
    
	return S_OK;
}


STDMETHODIMP CScene::AddLabel(BSTR LabelName, BSTR Caption, long Top, long Left, BSTR FontName)
{
	// Add new label to the labels collection
    USES_CONVERSION;//well i want to convert to ansi

    //create new label 
	abLabel *NewLabel;
	NewLabel=new abLabel();

    //Check if there is a valid font
    NewLabel->Font=GetFont(W2A(FontName));
    if (! NewLabel->Font) {//no valid font
        delete NewLabel;
        return S_OK;//exit function
    }

    NewLabel->Name=strdup(W2A(LabelName));
    NewLabel->Caption=strdup(W2A(Caption));
    NewLabel->Top=Top;
    NewLabel->Left=Left;
    NewLabel->Visible=TRUE;
    NewLabel->nxt=0;

	//add the new label to the labels collection
	if (! LabelsAnkor) {//check if first label
        LabelsAnkor=new abLabel();
		LabelsAnkor->nxt=NewLabel;//point to the first label
		NewLabel->prv=0;//no prev labels
	}
	else {//case its not the first label
		LastLabel->nxt = NewLabel;//update nxt pointer
		NewLabel->prv=LastLabel;//update prev pointer
	}
	
	LastLabel=NewLabel;//new label is now the last label

	return S_OK;
}

STDMETHODIMP CScene::AddFont(BSTR FontName, BSTR ImageName, long FontWidth, long FontHeight)
{
	// Add new font to the fonts collection
    USES_CONVERSION;//well i want to convert to ansi

    //create new font 
	abFont *NewFont;
	NewFont=new abFont();

    //Check if there is a valid font
    NewFont->FontImage=GetImage(W2A(ImageName));
    if (! NewFont->FontImage) {//no valid font
        delete NewFont;
        return S_OK;//exit function
    }

    NewFont->Name=strdup(W2A(FontName));
    NewFont->FontHeight=NewFont->FontImage->Height;
    NewFont->FontWidth=FontWidth;
    NewFont->nxt=0;

	//add the new font to the fonts collection
	if (! FontsAnkor) {//check if first font
        FontsAnkor=new abFont();
		FontsAnkor->nxt=NewFont;//point to the first font
		NewFont->prv=0;//no prev fonts
	}
	else {//case its not the first font
		LastFont->nxt = NewFont;//update nxt pointer
		NewFont->prv=LastFont;//update prev pointer
	}
	
	LastFont=NewFont;//new label is now the last label

	return S_OK;
}

STDMETHODIMP CScene::UpdateLabel(BSTR LabelName, BSTR Caption, VARIANT_BOOL Visible, long Top, long Left, BSTR FontName)
{
	// Update some properties in the specified label
    
    USES_CONVERSION;
    abLabel* tmpLabel=GetLabel(W2A(LabelName));
    
    if (tmpLabel) {//check if tmpLabel is valid
        char* sCaption=W2A(Caption);
        char* sFontName=W2A(FontName);
        if (strlen(sCaption)>0) {//change caption
            free(tmpLabel->Caption);
            tmpLabel->Caption=strdup(sCaption);
        }
        
        if (Visible!=-999) tmpLabel->Visible=Visible;//change visible (-999 = ignore)
        if (Top!=-1) tmpLabel->Top=Top;//change top pos (-1 = ignore)
        if (Left!=-1) tmpLabel->Left=Left;//change left pos (-1 = ignore)
        if (strlen(sFontName)>0) {//change font
            if (GetFont(sFontName)) {//is it a valid font?
                free(tmpLabel->Font);
                tmpLabel->Font=GetFont(sFontName);
            }
        }

    }//tmpLabel is valid
	return S_OK;
}

int PrintLabels() {

    abLabel* tmpLabel;

    if (LabelsAnkor){//case there is something in the collection
	    tmpLabel=LabelsAnkor->nxt ;//find the first label
    } else {
        return 0;
    }

	//main scan loop while names dont match and not end of collection
	while (tmpLabel!=NULL){
        if (tmpLabel->Visible) PrintCaption(tmpLabel);
        tmpLabel=tmpLabel->nxt;//next item
    }

    return 1;
}

int PrintCaption(abLabel* tmpLabel) {

    int i,iCounter;
    RECT rc;
    char* oldPointer=tmpLabel->Caption;

    iCounter=0;
    while (*tmpLabel->Caption) {//scan the label's caption
        i=*tmpLabel->Caption;
        //calc rect index position
        if (i>=48 && i<=90) {//numbers && big letters
            i-=48;
        } else if (i>=97 && i<=122) {//small letters
            i=i-53;
        } else {
            i=43;//space
        }

        //Calculate rect position
        rc.top=0;
        rc.bottom=tmpLabel->Font->FontImage->Height;
        rc.left=i*tmpLabel->Font->FontWidth;
        rc.right=rc.left+tmpLabel->Font->FontWidth;
        //Draw the letter to the screen
        lpDDSBack->BltFast(tmpLabel->Left+tmpLabel->Font->FontWidth*iCounter ,tmpLabel->Top,tmpLabel->Font->FontImage->ImageSurface1,&rc,DDBLTFAST_SRCCOLORKEY);
        iCounter++;
        tmpLabel->Caption++;//next letter
    }
    tmpLabel->Caption=oldPointer;//restore caption position
    return 1;
}

STDMETHODIMP CScene::DeleteLabel(BSTR Label)
{
	// Purpose: Delete the specified label from the collection
    USES_CONVERSION;
    DeleteLabelA(GetLabel(W2A(Label)));

	return S_OK;
}

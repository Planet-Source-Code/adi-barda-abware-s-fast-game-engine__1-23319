/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Jul 26 18:35:32 2001
 */
/* Compiler settings for D:\abSprite\abSpriteEX1.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __abSpriteEX1_h__
#define __abSpriteEX1_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IScene_FWD_DEFINED__
#define __IScene_FWD_DEFINED__
typedef interface IScene IScene;
#endif 	/* __IScene_FWD_DEFINED__ */


#ifndef __Scene_FWD_DEFINED__
#define __Scene_FWD_DEFINED__

#ifdef __cplusplus
typedef class Scene Scene;
#else
typedef struct Scene Scene;
#endif /* __cplusplus */

#endif 	/* __Scene_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IScene_INTERFACE_DEFINED__
#define __IScene_INTERFACE_DEFINED__

/* interface IScene */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IScene;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4475B401-5800-416E-AF41-8E763E654E3A")
    IScene : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Init( 
            /* [in] */ long Width,
            /* [in] */ long Height,
            /* [in] */ long ColorDepth) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HWND_Scene( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_HWND_Scene( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddImage( 
            /* [in] */ BSTR ImageName,
            /* [in] */ BSTR ImagePath) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddSprite( 
            /* [in] */ BSTR SpriteName,
            /* [in] */ BSTR ImageName,
            /* [in] */ int HorizonalFrames,
            /* [in] */ int VerticalFrames) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddBackground( 
            /* [in] */ BSTR Name,
            /* [in] */ BSTR ImagePath) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Restore( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Render( 
            /* [optional][in] */ VARIANT Background) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MoveSprite( 
            /* [in] */ BSTR Sprite,
            /* [in] */ int x,
            /* [in] */ int y,
            /* [in] */ int Frame) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddAction( 
            /* [in] */ BSTR Name,
            /* [in] */ int FromFrame,
            /* [in] */ int ToFrame,
            /* [in] */ int AutoReverse,
            /* [in] */ int EndFrame) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE StartAction( 
            /* [in] */ BSTR SpriteName,
            /* [in] */ BSTR ActionName,
            /* [in] */ int Continues) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE StopAction( 
            /* [in] */ BSTR SpriteName,
            /* [in] */ int Frame) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IsColide( 
            /* [in] */ BSTR Sprite1,
            /* [in] */ BSTR Sprite2,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *retval) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetActionSpeed( 
            /* [in] */ BSTR SpriteName,
            /* [in] */ int SpeedLevel) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RenderSpeed( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_RenderSpeed( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetSpriteImage( 
            /* [in] */ BSTR SpriteName,
            /* [in] */ BSTR ImageName,
            /* [in] */ int HorizonalFrames,
            /* [in] */ int VerticalFrames) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SpriteVisible( 
            /* [in] */ BSTR SpriteName,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SpriteVisible( 
            /* [in] */ BSTR SpriteName,
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteSprite( 
            /* [in] */ BSTR SpriteName) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AutoDelete( 
            /* [in] */ BSTR SpriteName,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AutoDelete( 
            /* [in] */ BSTR SpriteName,
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AutoActionSwitch( 
            /* [in] */ BSTR SpriteName,
            /* [in] */ BSTR ActionName,
            /* [in] */ BSTR ImageName,
            /* [in] */ int HorizonalFrames,
            /* [in] */ int VerticalFrames) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LoadMap( 
            /* [in] */ BSTR FileName,
            /* [in] */ long xRes,
            /* [in] */ long yRes) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetLayerImage( 
            /* [in] */ long LayerNum,
            /* [in] */ BSTR ImageName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ScrollLayer( 
            /* [in] */ long LayerNum,
            /* [in] */ long x,
            /* [in] */ long y) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddLabel( 
            /* [in] */ BSTR LabelName,
            /* [defaultvalue][in] */ BSTR Caption = L"",
            /* [defaultvalue][in] */ long Top = 0,
            /* [defaultvalue][in] */ long Left = 0,
            /* [defaultvalue][in] */ BSTR FontName = L"") = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddFont( 
            /* [in] */ BSTR FontName,
            /* [in] */ BSTR ImageName,
            /* [in] */ long FontWidth,
            /* [defaultvalue][in] */ long FontHeight = 0) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UpdateLabel( 
            /* [in] */ BSTR LabelName,
            /* [defaultvalue][in] */ BSTR Caption = L"",
            /* [defaultvalue][in] */ VARIANT_BOOL Visible = -999,
            /* [defaultvalue][in] */ long Top = -1,
            /* [defaultvalue][in] */ long Left = -1,
            /* [defaultvalue][in] */ BSTR FontName = L"") = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteLabel( 
            /* [in] */ BSTR Label) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISceneVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IScene __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IScene __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IScene __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IScene __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IScene __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IScene __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IScene __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Init )( 
            IScene __RPC_FAR * This,
            /* [in] */ long Width,
            /* [in] */ long Height,
            /* [in] */ long ColorDepth);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_HWND_Scene )( 
            IScene __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_HWND_Scene )( 
            IScene __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddImage )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR ImageName,
            /* [in] */ BSTR ImagePath);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddSprite )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [in] */ BSTR ImageName,
            /* [in] */ int HorizonalFrames,
            /* [in] */ int VerticalFrames);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddBackground )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR Name,
            /* [in] */ BSTR ImagePath);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Restore )( 
            IScene __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Render )( 
            IScene __RPC_FAR * This,
            /* [optional][in] */ VARIANT Background);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MoveSprite )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR Sprite,
            /* [in] */ int x,
            /* [in] */ int y,
            /* [in] */ int Frame);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddAction )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR Name,
            /* [in] */ int FromFrame,
            /* [in] */ int ToFrame,
            /* [in] */ int AutoReverse,
            /* [in] */ int EndFrame);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StartAction )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [in] */ BSTR ActionName,
            /* [in] */ int Continues);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StopAction )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [in] */ int Frame);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *IsColide )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR Sprite1,
            /* [in] */ BSTR Sprite2,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *retval);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetActionSpeed )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [in] */ int SpeedLevel);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RenderSpeed )( 
            IScene __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_RenderSpeed )( 
            IScene __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetSpriteImage )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [in] */ BSTR ImageName,
            /* [in] */ int HorizonalFrames,
            /* [in] */ int VerticalFrames);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SpriteVisible )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SpriteVisible )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteSprite )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AutoDelete )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AutoDelete )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AutoActionSwitch )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR SpriteName,
            /* [in] */ BSTR ActionName,
            /* [in] */ BSTR ImageName,
            /* [in] */ int HorizonalFrames,
            /* [in] */ int VerticalFrames);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadMap )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR FileName,
            /* [in] */ long xRes,
            /* [in] */ long yRes);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetLayerImage )( 
            IScene __RPC_FAR * This,
            /* [in] */ long LayerNum,
            /* [in] */ BSTR ImageName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ScrollLayer )( 
            IScene __RPC_FAR * This,
            /* [in] */ long LayerNum,
            /* [in] */ long x,
            /* [in] */ long y);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddLabel )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR LabelName,
            /* [defaultvalue][in] */ BSTR Caption,
            /* [defaultvalue][in] */ long Top,
            /* [defaultvalue][in] */ long Left,
            /* [defaultvalue][in] */ BSTR FontName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddFont )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR FontName,
            /* [in] */ BSTR ImageName,
            /* [in] */ long FontWidth,
            /* [defaultvalue][in] */ long FontHeight);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UpdateLabel )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR LabelName,
            /* [defaultvalue][in] */ BSTR Caption,
            /* [defaultvalue][in] */ VARIANT_BOOL Visible,
            /* [defaultvalue][in] */ long Top,
            /* [defaultvalue][in] */ long Left,
            /* [defaultvalue][in] */ BSTR FontName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteLabel )( 
            IScene __RPC_FAR * This,
            /* [in] */ BSTR Label);
        
        END_INTERFACE
    } ISceneVtbl;

    interface IScene
    {
        CONST_VTBL struct ISceneVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IScene_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IScene_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IScene_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IScene_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IScene_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IScene_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IScene_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IScene_Init(This,Width,Height,ColorDepth)	\
    (This)->lpVtbl -> Init(This,Width,Height,ColorDepth)

#define IScene_get_HWND_Scene(This,pVal)	\
    (This)->lpVtbl -> get_HWND_Scene(This,pVal)

#define IScene_put_HWND_Scene(This,newVal)	\
    (This)->lpVtbl -> put_HWND_Scene(This,newVal)

#define IScene_AddImage(This,ImageName,ImagePath)	\
    (This)->lpVtbl -> AddImage(This,ImageName,ImagePath)

#define IScene_AddSprite(This,SpriteName,ImageName,HorizonalFrames,VerticalFrames)	\
    (This)->lpVtbl -> AddSprite(This,SpriteName,ImageName,HorizonalFrames,VerticalFrames)

#define IScene_AddBackground(This,Name,ImagePath)	\
    (This)->lpVtbl -> AddBackground(This,Name,ImagePath)

#define IScene_Restore(This)	\
    (This)->lpVtbl -> Restore(This)

#define IScene_Render(This,Background)	\
    (This)->lpVtbl -> Render(This,Background)

#define IScene_MoveSprite(This,Sprite,x,y,Frame)	\
    (This)->lpVtbl -> MoveSprite(This,Sprite,x,y,Frame)

#define IScene_AddAction(This,Name,FromFrame,ToFrame,AutoReverse,EndFrame)	\
    (This)->lpVtbl -> AddAction(This,Name,FromFrame,ToFrame,AutoReverse,EndFrame)

#define IScene_StartAction(This,SpriteName,ActionName,Continues)	\
    (This)->lpVtbl -> StartAction(This,SpriteName,ActionName,Continues)

#define IScene_StopAction(This,SpriteName,Frame)	\
    (This)->lpVtbl -> StopAction(This,SpriteName,Frame)

#define IScene_IsColide(This,Sprite1,Sprite2,retval)	\
    (This)->lpVtbl -> IsColide(This,Sprite1,Sprite2,retval)

#define IScene_SetActionSpeed(This,SpriteName,SpeedLevel)	\
    (This)->lpVtbl -> SetActionSpeed(This,SpriteName,SpeedLevel)

#define IScene_get_RenderSpeed(This,pVal)	\
    (This)->lpVtbl -> get_RenderSpeed(This,pVal)

#define IScene_put_RenderSpeed(This,newVal)	\
    (This)->lpVtbl -> put_RenderSpeed(This,newVal)

#define IScene_SetSpriteImage(This,SpriteName,ImageName,HorizonalFrames,VerticalFrames)	\
    (This)->lpVtbl -> SetSpriteImage(This,SpriteName,ImageName,HorizonalFrames,VerticalFrames)

#define IScene_get_SpriteVisible(This,SpriteName,pVal)	\
    (This)->lpVtbl -> get_SpriteVisible(This,SpriteName,pVal)

#define IScene_put_SpriteVisible(This,SpriteName,newVal)	\
    (This)->lpVtbl -> put_SpriteVisible(This,SpriteName,newVal)

#define IScene_DeleteSprite(This,SpriteName)	\
    (This)->lpVtbl -> DeleteSprite(This,SpriteName)

#define IScene_get_AutoDelete(This,SpriteName,pVal)	\
    (This)->lpVtbl -> get_AutoDelete(This,SpriteName,pVal)

#define IScene_put_AutoDelete(This,SpriteName,newVal)	\
    (This)->lpVtbl -> put_AutoDelete(This,SpriteName,newVal)

#define IScene_AutoActionSwitch(This,SpriteName,ActionName,ImageName,HorizonalFrames,VerticalFrames)	\
    (This)->lpVtbl -> AutoActionSwitch(This,SpriteName,ActionName,ImageName,HorizonalFrames,VerticalFrames)

#define IScene_LoadMap(This,FileName,xRes,yRes)	\
    (This)->lpVtbl -> LoadMap(This,FileName,xRes,yRes)

#define IScene_SetLayerImage(This,LayerNum,ImageName)	\
    (This)->lpVtbl -> SetLayerImage(This,LayerNum,ImageName)

#define IScene_ScrollLayer(This,LayerNum,x,y)	\
    (This)->lpVtbl -> ScrollLayer(This,LayerNum,x,y)

#define IScene_AddLabel(This,LabelName,Caption,Top,Left,FontName)	\
    (This)->lpVtbl -> AddLabel(This,LabelName,Caption,Top,Left,FontName)

#define IScene_AddFont(This,FontName,ImageName,FontWidth,FontHeight)	\
    (This)->lpVtbl -> AddFont(This,FontName,ImageName,FontWidth,FontHeight)

#define IScene_UpdateLabel(This,LabelName,Caption,Visible,Top,Left,FontName)	\
    (This)->lpVtbl -> UpdateLabel(This,LabelName,Caption,Visible,Top,Left,FontName)

#define IScene_DeleteLabel(This,Label)	\
    (This)->lpVtbl -> DeleteLabel(This,Label)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_Init_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ long Width,
    /* [in] */ long Height,
    /* [in] */ long ColorDepth);


void __RPC_STUB IScene_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IScene_get_HWND_Scene_Proxy( 
    IScene __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IScene_get_HWND_Scene_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IScene_put_HWND_Scene_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IScene_put_HWND_Scene_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_AddImage_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR ImageName,
    /* [in] */ BSTR ImagePath);


void __RPC_STUB IScene_AddImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_AddSprite_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [in] */ BSTR ImageName,
    /* [in] */ int HorizonalFrames,
    /* [in] */ int VerticalFrames);


void __RPC_STUB IScene_AddSprite_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_AddBackground_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR Name,
    /* [in] */ BSTR ImagePath);


void __RPC_STUB IScene_AddBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_Restore_Proxy( 
    IScene __RPC_FAR * This);


void __RPC_STUB IScene_Restore_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_Render_Proxy( 
    IScene __RPC_FAR * This,
    /* [optional][in] */ VARIANT Background);


void __RPC_STUB IScene_Render_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_MoveSprite_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR Sprite,
    /* [in] */ int x,
    /* [in] */ int y,
    /* [in] */ int Frame);


void __RPC_STUB IScene_MoveSprite_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_AddAction_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR Name,
    /* [in] */ int FromFrame,
    /* [in] */ int ToFrame,
    /* [in] */ int AutoReverse,
    /* [in] */ int EndFrame);


void __RPC_STUB IScene_AddAction_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_StartAction_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [in] */ BSTR ActionName,
    /* [in] */ int Continues);


void __RPC_STUB IScene_StartAction_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_StopAction_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [in] */ int Frame);


void __RPC_STUB IScene_StopAction_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_IsColide_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR Sprite1,
    /* [in] */ BSTR Sprite2,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *retval);


void __RPC_STUB IScene_IsColide_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_SetActionSpeed_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [in] */ int SpeedLevel);


void __RPC_STUB IScene_SetActionSpeed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IScene_get_RenderSpeed_Proxy( 
    IScene __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IScene_get_RenderSpeed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IScene_put_RenderSpeed_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IScene_put_RenderSpeed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_SetSpriteImage_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [in] */ BSTR ImageName,
    /* [in] */ int HorizonalFrames,
    /* [in] */ int VerticalFrames);


void __RPC_STUB IScene_SetSpriteImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IScene_get_SpriteVisible_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IScene_get_SpriteVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IScene_put_SpriteVisible_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IScene_put_SpriteVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_DeleteSprite_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName);


void __RPC_STUB IScene_DeleteSprite_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IScene_get_AutoDelete_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IScene_get_AutoDelete_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IScene_put_AutoDelete_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IScene_put_AutoDelete_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_AutoActionSwitch_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR SpriteName,
    /* [in] */ BSTR ActionName,
    /* [in] */ BSTR ImageName,
    /* [in] */ int HorizonalFrames,
    /* [in] */ int VerticalFrames);


void __RPC_STUB IScene_AutoActionSwitch_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_LoadMap_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR FileName,
    /* [in] */ long xRes,
    /* [in] */ long yRes);


void __RPC_STUB IScene_LoadMap_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_SetLayerImage_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ long LayerNum,
    /* [in] */ BSTR ImageName);


void __RPC_STUB IScene_SetLayerImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_ScrollLayer_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ long LayerNum,
    /* [in] */ long x,
    /* [in] */ long y);


void __RPC_STUB IScene_ScrollLayer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_AddLabel_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR LabelName,
    /* [defaultvalue][in] */ BSTR Caption,
    /* [defaultvalue][in] */ long Top,
    /* [defaultvalue][in] */ long Left,
    /* [defaultvalue][in] */ BSTR FontName);


void __RPC_STUB IScene_AddLabel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_AddFont_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR FontName,
    /* [in] */ BSTR ImageName,
    /* [in] */ long FontWidth,
    /* [defaultvalue][in] */ long FontHeight);


void __RPC_STUB IScene_AddFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_UpdateLabel_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR LabelName,
    /* [defaultvalue][in] */ BSTR Caption,
    /* [defaultvalue][in] */ VARIANT_BOOL Visible,
    /* [defaultvalue][in] */ long Top,
    /* [defaultvalue][in] */ long Left,
    /* [defaultvalue][in] */ BSTR FontName);


void __RPC_STUB IScene_UpdateLabel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IScene_DeleteLabel_Proxy( 
    IScene __RPC_FAR * This,
    /* [in] */ BSTR Label);


void __RPC_STUB IScene_DeleteLabel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IScene_INTERFACE_DEFINED__ */



#ifndef __ABSPRITEEX1Lib_LIBRARY_DEFINED__
#define __ABSPRITEEX1Lib_LIBRARY_DEFINED__

/* library ABSPRITEEX1Lib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ABSPRITEEX1Lib;

EXTERN_C const CLSID CLSID_Scene;

#ifdef __cplusplus

class DECLSPEC_UUID("89028D1D-C750-422E-9376-91E1E9CEF71A")
Scene;
#endif
#endif /* __ABSPRITEEX1Lib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif

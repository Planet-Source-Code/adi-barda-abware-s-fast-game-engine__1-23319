//bmp.h: header file for the bmp file reader

//Copyright Ian Parberry, 1999
//Last updated September 2, 1999



#ifndef __bmp_h__
#define __bmp_h__

class CBmpFileReader{ //bmp file input class

};

#endif

// BmpHandler.h: interface for the CBmpHandler class.
//
//////////////////////////////////////////////////////////////////////

#include <ddraw.h>
#include "defines.h"

#if !defined(AFX_BMPHANDLER_H__DA04A893_B531_410A_BAB7_EC9FF77D34E8__INCLUDED_)
#define AFX_BMPHANDLER_H__DA04A893_B531_410A_BAB7_EC9FF77D34E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



class CBmpHandler  
{
public:
	CBmpHandler();
	virtual ~CBmpHandler();
  protected:
    BITMAPFILEHEADER m_BMPFileHead; //bmp header
    BITMAPINFOHEADER m_BMPFileInfo; //bmp file information
    RGBQUAD m_rgbPalette[COLORS]; //the palette
    BYTE *m_cImage; //the image
  public:
    BOOL load(char *filename); //load from file
    BOOL draw(LPDIRECTDRAWSURFACE surface); //draw image
    BOOL setpalette(LPDIRECTDRAWPALETTE palette); //set palette
};

#endif // !defined(AFX_BMPHANDLER_H__DA04A893_B531_410A_BAB7_EC9FF77D34E8__INCLUDED_)

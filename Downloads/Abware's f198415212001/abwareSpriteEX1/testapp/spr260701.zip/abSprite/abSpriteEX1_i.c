/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Jul 26 18:35:32 2001
 */
/* Compiler settings for D:\abSprite\abSpriteEX1.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IScene = {0x4475B401,0x5800,0x416E,{0xAF,0x41,0x8E,0x76,0x3E,0x65,0x4E,0x3A}};


const IID LIBID_ABSPRITEEX1Lib = {0x60C7082E,0x7926,0x4068,{0xBA,0x32,0xBB,0xAE,0xBB,0xF7,0x07,0xB1}};


const CLSID CLSID_Scene = {0x89028D1D,0xC750,0x422E,{0x93,0x76,0x91,0xE1,0xE9,0xCE,0xF7,0x1A}};


#ifdef __cplusplus
}
#endif


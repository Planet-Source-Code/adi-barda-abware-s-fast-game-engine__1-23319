// Scene.h : Declaration of the CScene

#ifndef __SCENE_H_
#define __SCENE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CScene
class ATL_NO_VTABLE CScene : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CScene, &CLSID_Scene>,
	public IDispatchImpl<IScene, &IID_IScene, &LIBID_ABSPRITEEX1Lib>
{
public:
	CScene()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCENE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CScene)
	COM_INTERFACE_ENTRY(IScene)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IScene
public:
	STDMETHOD(DeleteLabel)(/*[in]*/ BSTR Label);
	STDMETHOD(UpdateLabel)(/*[in]*/ BSTR LabelName,/*[in,defaultvalue("")]*/ BSTR Caption,/*[in,defaultvalue(-999)]*/ VARIANT_BOOL Visible,/*[in,defaultvalue(-1)]*/ long Top,/*[in,defaultvalue(-1)]*/ long Left,/*[in,defaultvalue("")]*/ BSTR FontName  );
	STDMETHOD(AddFont)(/*[in]*/ BSTR FontName,/*[in]*/ BSTR ImageName,/*[in]*/ long FontWidth,/*[in,defaultvalue(0)]*/ long FontHeight);
	STDMETHOD(AddLabel)(/*[in]*/ BSTR LabelName,/*[in,defaultvalue("")]*/ BSTR Caption,/*[in,defaultvalue(0)]*/ long Top,/*[in, defaultvalue(0)]*/ long Left,/*[in, defaultvalue("")]*/ BSTR FontName);
	STDMETHOD(ScrollLayer)(/*[in]*/ long LayerNum,/*[in]*/ long x,/*[in]*/ long y);
	STDMETHOD(SetLayerImage)(/*[in]*/ long LayerNum,/*[in]*/ BSTR ImageName);
	STDMETHOD(LoadMap)(/*[in]*/ BSTR FileName,/*[in]*/ long xRes,/*[in]*/ long yRes);
	STDMETHOD(AutoActionSwitch)(/*[in]*/ BSTR SpriteName,/*[in]*/ BSTR ActionName, BSTR ImageName,int HorizonalFrames, int VerticalFrames);
	STDMETHOD(get_AutoDelete)(/*[in]*/ BSTR SpriteName, /*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_AutoDelete)(/*[in]*/ BSTR SpriteName, /*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(DeleteSprite)(/*[in]*/ BSTR SpriteName);
	STDMETHOD(get_SpriteVisible)(/*[in]*/ BSTR SpriteName, /*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_SpriteVisible)(/*[in]*/ BSTR SpriteName, /*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(SetSpriteImage)(/*[in]*/ BSTR SpriteName,/*[in]*/ BSTR ImageName,/*[in]*/ int HorizonalFrames,/*[in]*/ int VerticalFrames);
	STDMETHOD(get_RenderSpeed)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_RenderSpeed)(/*[in]*/ long newVal);
	STDMETHOD(SetActionSpeed)(/*[in]*/ BSTR SpriteName,/*[in]*/ int SpeedLevel);
	STDMETHOD(IsColide)(/*[in]*/ BSTR Sprite1,/*[in]*/ BSTR Sprite2,/*[out,retval]*/ VARIANT_BOOL* retval);
	STDMETHOD(StopAction)(/*[in]*/ BSTR SpriteName, /*[in]*/ int Frame);
	STDMETHOD(StartAction)(/*[in]*/ BSTR SpriteName, /*[in]*/ BSTR ActionName,/*[in]*/ int Continues);
	STDMETHOD(AddAction)(/*[in]*/ BSTR Name,/*[in]*/ int FromFrame,/*[in]*/ int ToFrame,/*[in]*/ int AutoReverse,/*[in]*/ int EndFrame);
	STDMETHOD(MoveSprite)(/*[in]*/ BSTR Sprite,/*[in]*/ int x,/*[in]*/ int y,/*[in]*/ int Frame);
	STDMETHOD(Render)(/*[in]*/ VARIANT Background);
	STDMETHOD(Restore)();
	STDMETHOD(AddBackground)(/*[in]*/ BSTR Name,/*[in]*/ BSTR ImagePath);
	STDMETHOD(AddSprite)(/*[in]*/ BSTR SpriteName,/*[in]*/ BSTR ImageName,int HorizonalFrames,int VerticalFrames);
	STDMETHOD(AddImage)(/*[in]*/ BSTR ImageName,/*[in]*/ BSTR ImagePath);
	STDMETHOD(get_HWND_Scene)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_HWND_Scene)(/*[in]*/ long newVal);
	STDMETHOD(Init)(/*[in]*/ long Width,/*[in]*/ long Height, /*[in]*/ long ColorDepth);
};

#endif //__SCENE_H_

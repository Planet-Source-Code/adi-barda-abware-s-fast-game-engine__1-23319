// DDSetupEX.h: interface for the CDDSetupEX class.
//
//////////////////////////////////////////////////////////////////////

#include <ddraw.h>
#include "defines.h"

//globals
extern LPDIRECTDRAW lpDirectDrawObject; //direct draw object
extern LPDIRECTDRAWSURFACE lpPrimary; //primary surface
extern LPDIRECTDRAWPALETTE lpPrimaryPalette; //its palette

//helper functions

#if !defined(AFX_DDSETUPEX_H__E3F97B73_CAB3_422B_835F_A809973DDAA5__INCLUDED_)
#define AFX_DDSETUPEX_H__E3F97B73_CAB3_422B_835F_A809973DDAA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDDSetupEX  
{
public:
	CDDSetupEX();
	virtual ~CDDSetupEX();
LPDIRECTDRAWPALETTE CreatePalette(LPDIRECTDRAWSURFACE surface);
BOOL InitDirectDraw(HWND hwnd);

};

#endif // !defined(AFX_DDSETUPEX_H__E3F97B73_CAB3_422B_835F_A809973DDAA5__INCLUDED_)

// DDSetupEX.cpp: implementation of the CDDSetupEX class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DDSetupEX.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDDSetupEX::CDDSetupEX()
{

}

CDDSetupEX::~CDDSetupEX()
{

}

//ddsetup.cpp: directDraw setup and release
//Copyright Ian Parberry, 1999
//Last updated May 22, 2000

//system includes


LPDIRECTDRAWPALETTE CreatePalette(LPDIRECTDRAWSURFACE surface){
//create surface palette
  PALETTEENTRY pe[COLORS]; //new palette
  LPDIRECTDRAWPALETTE lpDDPalette; //direct draw palette
  //construct pe[], set to black
  for(int i=0; i<COLORS; i++)
    pe[i].peRed=pe[i].peGreen=pe[i].peBlue=0;
  //create direct draw palette
  if(FAILED(lpDirectDrawObject->
  CreatePalette(DDPCAPS_8BIT,pe,&lpDDPalette,NULL)))
    return NULL;
  //load direct draw palette to surface
  surface->SetPalette(lpDDPalette);
  return lpDDPalette;
} //CreatePalette

BOOL InitDirectDraw(HWND hwnd){ //direct draw initialization
  //create and set up direct draw object
  if(FAILED(DirectDrawCreate(NULL,&lpDirectDrawObject,NULL)))
    return FALSE;
  //set cooperative level
  if(FAILED(lpDirectDrawObject->SetCooperativeLevel(hwnd,
  DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN)))
    return FALSE;
  //change screen resolution
  if(FAILED(lpDirectDrawObject->
  SetDisplayMode(SCREEN_WIDTH,SCREEN_HEIGHT,COLOR_DEPTH)))
    return FALSE;
  //create the primary surface
  DDSURFACEDESC ddsd; //direct draw surface descriptor
  ddsd.dwSize=sizeof(ddsd);
  ddsd.dwFlags=DDSD_CAPS;
  ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;
  if(FAILED(lpDirectDrawObject->
  CreateSurface(&ddsd,&lpPrimary,NULL)))
    return FALSE;
  //create its palette
  lpPrimaryPalette=CreatePalette(lpPrimary);
  return TRUE;
} //InitDirectDraw


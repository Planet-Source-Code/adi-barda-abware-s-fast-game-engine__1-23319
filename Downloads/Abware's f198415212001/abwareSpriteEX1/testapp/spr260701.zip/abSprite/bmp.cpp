//bmp.cpp: member functions for the bmp file reader

//Copyright Ian Parberry, 1999
//Last updated May 22, 2000
#include "stdafx.h"
#include "bmp.h" //header file

//constructors and destructors

CBmpFileReader::CBmpFileReader(){ //constructor
  
}

CBmpFileReader::~CBmpFileReader(){ //destructor
  
}

//member functions

